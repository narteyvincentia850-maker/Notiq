import { Router } from "express";
import { requireAuth, getUser } from "../lib/auth.js";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { InitializePaymentBody } from "@workspace/api-zod";

const router = Router();
router.use(requireAuth);

const PAYSTACK_SECRET_KEY = process.env.PAYSTACK_SECRET_KEY;

router.post("/initialize", async (req, res): Promise<void> => {
  const parsed = InitializePaymentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Invalid input" });
    return;
  }

  if (!PAYSTACK_SECRET_KEY) {
    res.status(500).json({ message: "Paystack not configured" });
    return;
  }

  const { email, amount, plan, callbackUrl } = parsed.data;

  const response = await fetch("https://api.paystack.co/transaction/initialize", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${PAYSTACK_SECRET_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      email,
      amount: amount * 100,
      callback_url: callbackUrl,
      metadata: {
        plan,
        userId: getUser(req).id,
      },
    }),
  });

  if (!response.ok) {
    const errText = await response.text();
    req.log.error({ status: response.status, body: errText }, "Paystack init error");
    res.status(502).json({ message: "Payment initialization failed" });
    return;
  }

  const data = await response.json() as any;
  res.json({
    authorizationUrl: data.data.authorization_url,
    accessCode: data.data.access_code,
    reference: data.data.reference,
  });
});

router.get("/verify/:reference", async (req, res): Promise<void> => {
  const { reference } = req.params;
  const user = getUser(req);

  if (!PAYSTACK_SECRET_KEY) {
    res.status(500).json({ message: "Paystack not configured" });
    return;
  }

  const response = await fetch(`https://api.paystack.co/transaction/verify/${reference}`, {
    headers: {
      "Authorization": `Bearer ${PAYSTACK_SECRET_KEY}`,
    },
  });

  if (!response.ok) {
    res.status(502).json({ message: "Verification failed" });
    return;
  }

  const data = await response.json() as any;
  const status = data?.data?.status;

  if (status === "success") {
    await db.update(usersTable).set({ tier: "premium" }).where(eq(usersTable.id, user.id));
    res.json({ status: "success", tier: "premium", reference });
  } else {
    res.json({ status: status ?? "failed", tier: "free", reference });
  }
});

export default router;
