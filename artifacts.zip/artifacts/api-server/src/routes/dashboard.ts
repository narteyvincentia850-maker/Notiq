import { Router } from "express";
import { requireAuth, getUser } from "../lib/auth.js";
import { db, notesTable, assignmentsTable, gradesTable, attendanceTable, slidesTable, feedbackTable, contactsTable, projectsTable, invoicesTable } from "@workspace/db";
import { eq, and, count, avg, sum } from "drizzle-orm";

const router = Router();
router.use(requireAuth);

router.get("/student", async (req, res): Promise<void> => {
  const user = getUser(req);

  const [notesResult] = await db.select({ count: count() }).from(notesTable).where(eq(notesTable.userId, user.id));
  const [pendingResult] = await db.select({ count: count() }).from(assignmentsTable).where(and(eq(assignmentsTable.userId, user.id), eq(assignmentsTable.status, "pending")));
  const [avgGradeResult] = await db.select({ avg: avg(gradesTable.score) }).from(gradesTable).where(eq(gradesTable.userId, user.id));

  const recentNotes = await db.select().from(notesTable).where(eq(notesTable.userId, user.id)).orderBy(notesTable.createdAt).limit(5);
  const upcomingAssignments = await db.select().from(assignmentsTable).where(and(eq(assignmentsTable.userId, user.id), eq(assignmentsTable.status, "pending"))).orderBy(assignmentsTable.dueDate).limit(5);
  const allGrades = await db.select().from(gradesTable).where(eq(gradesTable.userId, user.id));

  const gradeBreakdown = allGrades.map(g => ({ subject: g.subject, grade: g.grade, score: g.score }));

  res.json({
    totalNotes: notesResult.count,
    pendingAssignments: pendingResult.count,
    averageGrade: Number(avgGradeResult.avg ?? 0),
    recentNotes: recentNotes.map(n => ({ ...n, tags: n.tags ?? [], createdAt: n.createdAt.toISOString(), updatedAt: n.updatedAt.toISOString() })),
    upcomingAssignments: upcomingAssignments.map(a => ({ ...a, createdAt: a.createdAt.toISOString() })),
    gradeBreakdown,
  });
});

router.get("/professor", async (req, res): Promise<void> => {
  const user = getUser(req);

  const todayDate = new Date().toISOString().split("T")[0];
  const [todayResult] = await db.select({ count: count() }).from(attendanceTable).where(and(eq(attendanceTable.userId, user.id), eq(attendanceTable.date, todayDate)));
  const [slidesResult] = await db.select({ count: count() }).from(slidesTable).where(eq(slidesTable.userId, user.id));
  const allAttendance = await db.select().from(attendanceTable).where(eq(attendanceTable.userId, user.id));
  const presentCount = allAttendance.filter(a => a.status === "present").length;
  const attendanceRate = allAttendance.length > 0 ? (presentCount / allAttendance.length) * 100 : 0;

  const recentAttendance = await db.select().from(attendanceTable).where(eq(attendanceTable.userId, user.id)).orderBy(attendanceTable.date).limit(10);
  const recentFeedback = await db.select().from(feedbackTable).where(eq(feedbackTable.userId, user.id)).orderBy(feedbackTable.createdAt).limit(5);

  const uniqueStudents = new Set(allAttendance.map(a => a.studentName)).size;

  res.json({
    totalStudents: uniqueStudents,
    todayAttendance: todayResult.count,
    totalSlides: slidesResult.count,
    attendanceRate: Math.round(attendanceRate),
    recentAttendance: recentAttendance.map(a => ({ ...a, createdAt: a.createdAt.toISOString() })),
    recentFeedback: recentFeedback.map(f => ({ ...f, createdAt: f.createdAt.toISOString() })),
  });
});

router.get("/business", async (req, res): Promise<void> => {
  const user = getUser(req);

  const [contactsResult] = await db.select({ count: count() }).from(contactsTable).where(eq(contactsTable.userId, user.id));
  const [activeProjectsResult] = await db.select({ count: count() }).from(projectsTable).where(and(eq(projectsTable.userId, user.id), eq(projectsTable.status, "active")));
  const [revenueResult] = await db.select({ total: sum(invoicesTable.amount) }).from(invoicesTable).where(and(eq(invoicesTable.userId, user.id), eq(invoicesTable.status, "paid")));
  const [pendingInvoicesResult] = await db.select({ count: count() }).from(invoicesTable).where(and(eq(invoicesTable.userId, user.id), eq(invoicesTable.status, "sent")));

  const recentContacts = await db.select().from(contactsTable).where(eq(contactsTable.userId, user.id)).orderBy(contactsTable.createdAt).limit(5);
  const recentInvoices = await db.select().from(invoicesTable).where(eq(invoicesTable.userId, user.id)).orderBy(invoicesTable.createdAt).limit(5);
  const allContacts = await db.select().from(contactsTable).where(eq(contactsTable.userId, user.id));

  const statusCounts: Record<string, number> = {};
  for (const c of allContacts) {
    statusCounts[c.status] = (statusCounts[c.status] ?? 0) + 1;
  }
  const contactsByStatus = Object.entries(statusCounts).map(([status, count]) => ({ status, count }));

  res.json({
    totalContacts: contactsResult.count,
    activeProjects: activeProjectsResult.count,
    totalRevenue: Number(revenueResult.total ?? 0),
    pendingInvoices: pendingInvoicesResult.count,
    recentContacts: recentContacts.map(c => ({ ...c, createdAt: c.createdAt.toISOString() })),
    recentInvoices: recentInvoices.map(i => ({ ...i, createdAt: i.createdAt.toISOString() })),
    contactsByStatus,
  });
});

export default router;
