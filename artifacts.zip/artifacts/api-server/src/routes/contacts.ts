import { Router } from "express";
import { db, contactsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { requireAuth, getUser } from "../lib/auth.js";
import { CreateContactBody, UpdateContactBody } from "@workspace/api-zod";

const router = Router();
router.use(requireAuth);

router.get("/", async (req, res): Promise<void> => {
  const user = getUser(req);
  const rows = await db.select().from(contactsTable).where(eq(contactsTable.userId, user.id)).orderBy(contactsTable.createdAt);
  res.json(rows.map(r => ({ ...r, createdAt: r.createdAt.toISOString() })));
});

router.post("/", async (req, res): Promise<void> => {
  const user = getUser(req);
  const parsed = CreateContactBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ message: "Invalid input" }); return; }
  const [row] = await db.insert(contactsTable).values({ ...parsed.data, userId: user.id }).returning();
  res.status(201).json({ ...row, createdAt: row.createdAt.toISOString() });
});

router.put("/:id", async (req, res): Promise<void> => {
  const user = getUser(req);
  const id = Number(req.params.id);
  const parsed = UpdateContactBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ message: "Invalid input" }); return; }
  const [row] = await db.update(contactsTable).set(parsed.data).where(and(eq(contactsTable.id, id), eq(contactsTable.userId, user.id))).returning();
  if (!row) { res.status(404).json({ message: "Not found" }); return; }
  res.json({ ...row, createdAt: row.createdAt.toISOString() });
});

router.delete("/:id", async (req, res): Promise<void> => {
  const user = getUser(req);
  const id = Number(req.params.id);
  await db.delete(contactsTable).where(and(eq(contactsTable.id, id), eq(contactsTable.userId, user.id)));
  res.json({ message: "Deleted" });
});

export default router;
