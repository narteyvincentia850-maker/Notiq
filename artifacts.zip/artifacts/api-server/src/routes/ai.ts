import { Router } from "express";
import { requireAuth, getUser } from "../lib/auth.js";
import { TranscribeAudioBody, SummarizeTextBody, ChatWithAIBody } from "@workspace/api-zod";

const router = Router();
router.use(requireAuth);

const DEEPGRAM_API_KEY = process.env.DEEPGRAM_API_KEY;
const GROQ_API_KEY = process.env.GROQ_API_KEY;

router.get("/deepgram-key", (_req, res): void => {
  if (!DEEPGRAM_API_KEY) {
    res.status(500).json({ message: "Deepgram API key not configured" });
    return;
  }
  res.json({ key: DEEPGRAM_API_KEY });
});

router.post("/transcribe", async (req, res): Promise<void> => {
  const parsed = TranscribeAudioBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Invalid input" });
    return;
  }

  if (!DEEPGRAM_API_KEY) {
    res.status(500).json({ message: "Deepgram API key not configured" });
    return;
  }

  const { audioBase64, mimeType } = parsed.data;
  const audioBuffer = Buffer.from(audioBase64, "base64");

  const response = await fetch("https://api.deepgram.com/v1/listen?model=nova-2&smart_format=true", {
    method: "POST",
    headers: {
      "Authorization": `Token ${DEEPGRAM_API_KEY}`,
      "Content-Type": mimeType,
    },
    body: audioBuffer,
  });

  if (!response.ok) {
    const errText = await response.text();
    req.log.error({ status: response.status, body: errText }, "Deepgram error");
    res.status(502).json({ message: "Transcription failed" });
    return;
  }

  const data = await response.json() as any;
  const transcript = data?.results?.channels?.[0]?.alternatives?.[0]?.transcript ?? "";
  const words = data?.results?.channels?.[0]?.alternatives?.[0]?.words?.length ?? 0;
  const confidence = data?.results?.channels?.[0]?.alternatives?.[0]?.confidence ?? 0;

  res.json({ transcript, confidence, words });
});

router.post("/summarize", async (req, res): Promise<void> => {
  const parsed = SummarizeTextBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Invalid input" });
    return;
  }

  if (!GROQ_API_KEY) {
    res.status(500).json({ message: "Groq API key not configured" });
    return;
  }

  const { text, context } = parsed.data;
  const systemPrompt = context
    ? `You are a smart note-taking assistant. Context: ${context}. Summarize the following text concisely and extract key points.`
    : "You are a smart note-taking assistant. Summarize the following text concisely and extract key points as a JSON object.";

  const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${GROQ_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: "llama3-8b-8192",
      messages: [
        { role: "system", content: systemPrompt + '\n\nRespond with valid JSON only: {"summary": "...", "keyPoints": ["...", "..."]}' },
        { role: "user", content: text },
      ],
      temperature: 0.3,
      max_tokens: 1024,
    }),
  });

  if (!response.ok) {
    const errText = await response.text();
    req.log.error({ status: response.status, body: errText }, "Groq error");
    res.status(502).json({ message: "Summarization failed" });
    return;
  }

  const data = await response.json() as any;
  const content = data?.choices?.[0]?.message?.content ?? "{}";

  let summary = "";
  let keyPoints: string[] = [];
  try {
    const parsed = JSON.parse(content);
    summary = parsed.summary ?? content;
    keyPoints = parsed.keyPoints ?? [];
  } catch {
    summary = content;
    keyPoints = [];
  }

  res.json({ summary, keyPoints });
});

router.post("/chat", async (req, res): Promise<void> => {
  const parsed = ChatWithAIBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Invalid input" });
    return;
  }

  if (!GROQ_API_KEY) {
    res.status(500).json({ message: "Groq API key not configured" });
    return;
  }

  const { messages, context } = parsed.data;
  const systemMessage = context
    ? `You are Notiq AI, a helpful assistant for note-taking and productivity. Context from user's notes: ${context}`
    : "You are Notiq AI, a helpful assistant for note-taking, studying, and productivity. Be concise and helpful.";

  const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${GROQ_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: "llama3-8b-8192",
      messages: [
        { role: "system", content: systemMessage },
        ...messages,
      ],
      temperature: 0.7,
      max_tokens: 1024,
    }),
  });

  if (!response.ok) {
    const errText = await response.text();
    req.log.error({ status: response.status, body: errText }, "Groq chat error");
    res.status(502).json({ message: "Chat failed" });
    return;
  }

  const data = await response.json() as any;
  const message = data?.choices?.[0]?.message?.content ?? "";
  const role = data?.choices?.[0]?.message?.role ?? "assistant";

  res.json({ message, role });
});

export default router;
