import { Router } from "express";
import { db, notesTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { requireAuth, getUser } from "../lib/auth.js";
import { CreateNoteBody, UpdateNoteBody, ListNotesQueryParams } from "@workspace/api-zod";

const router = Router();

router.use(requireAuth);

router.get("/", async (req, res): Promise<void> => {
  const user = getUser(req);
  const queryParsed = ListNotesQueryParams.safeParse(req.query);
  const portal = queryParsed.success ? queryParsed.data.portal : undefined;

  const conditions = portal
    ? [eq(notesTable.userId, user.id), eq(notesTable.portal, portal)]
    : [eq(notesTable.userId, user.id)];

  const notes = await db.select().from(notesTable).where(and(...conditions)).orderBy(notesTable.createdAt);
  res.json(notes.map(n => ({
    ...n,
    tags: n.tags ?? [],
    createdAt: n.createdAt.toISOString(),
    updatedAt: n.updatedAt.toISOString(),
  })));
});

router.post("/", async (req, res): Promise<void> => {
  const user = getUser(req);
  const parsed = CreateNoteBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Invalid input" });
    return;
  }
  const [note] = await db.insert(notesTable).values({ ...parsed.data, userId: user.id }).returning();
  res.status(201).json({ ...note, tags: note.tags ?? [], createdAt: note.createdAt.toISOString(), updatedAt: note.updatedAt.toISOString() });
});

router.get("/:id", async (req, res): Promise<void> => {
  const user = getUser(req);
  const id = Number(req.params.id);
  const [note] = await db.select().from(notesTable).where(and(eq(notesTable.id, id), eq(notesTable.userId, user.id))).limit(1);
  if (!note) { res.status(404).json({ message: "Not found" }); return; }
  res.json({ ...note, tags: note.tags ?? [], createdAt: note.createdAt.toISOString(), updatedAt: note.updatedAt.toISOString() });
});

router.put("/:id", async (req, res): Promise<void> => {
  const user = getUser(req);
  const id = Number(req.params.id);
  const parsed = UpdateNoteBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ message: "Invalid input" }); return; }
  const [note] = await db.update(notesTable).set({ ...parsed.data, updatedAt: new Date() }).where(and(eq(notesTable.id, id), eq(notesTable.userId, user.id))).returning();
  if (!note) { res.status(404).json({ message: "Not found" }); return; }
  res.json({ ...note, tags: note.tags ?? [], createdAt: note.createdAt.toISOString(), updatedAt: note.updatedAt.toISOString() });
});

router.delete("/:id", async (req, res): Promise<void> => {
  const user = getUser(req);
  const id = Number(req.params.id);
  await db.delete(notesTable).where(and(eq(notesTable.id, id), eq(notesTable.userId, user.id)));
  res.json({ message: "Deleted" });
});

export default router;
