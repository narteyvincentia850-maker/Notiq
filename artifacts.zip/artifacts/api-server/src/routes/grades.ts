import { Router } from "express";
import { db, gradesTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth, getUser } from "../lib/auth.js";
import { CreateGradeBody } from "@workspace/api-zod";

const router = Router();
router.use(requireAuth);

router.get("/", async (req, res): Promise<void> => {
  const user = getUser(req);
  const rows = await db.select().from(gradesTable).where(eq(gradesTable.userId, user.id)).orderBy(gradesTable.createdAt);
  res.json(rows.map(r => ({ ...r, createdAt: r.createdAt.toISOString() })));
});

router.post("/", async (req, res): Promise<void> => {
  const user = getUser(req);
  const parsed = CreateGradeBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ message: "Invalid input" }); return; }
  const [row] = await db.insert(gradesTable).values({ ...parsed.data, userId: user.id }).returning();
  res.status(201).json({ ...row, createdAt: row.createdAt.toISOString() });
});

export default router;
