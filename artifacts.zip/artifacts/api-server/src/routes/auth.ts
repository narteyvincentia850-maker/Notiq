import { Router } from "express";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { hashPassword, comparePassword, signToken, requireAuth, getUser } from "../lib/auth.js";
import { RegisterBody, LoginBody } from "@workspace/api-zod";

const router = Router();

router.post("/register", async (req, res): Promise<void> => {
  const parsed = RegisterBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Invalid input" });
    return;
  }
  const { email, password, name, role } = parsed.data;

  const [existing] = await db.select().from(usersTable).where(eq(usersTable.email, email)).limit(1);
  if (existing) {
    res.status(409).json({ message: "Email already registered" });
    return;
  }

  const passwordHash = await hashPassword(password);
  const [user] = await db.insert(usersTable).values({ email, passwordHash, name, role, tier: "free" }).returning();
  const token = signToken(user.id);

  res.status(201).json({
    user: { id: user.id, email: user.email, name: user.name, role: user.role, tier: user.tier, createdAt: user.createdAt.toISOString() },
    token,
  });
});

router.post("/login", async (req, res): Promise<void> => {
  const parsed = LoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Invalid input" });
    return;
  }
  const { email, password } = parsed.data;

  const [user] = await db.select().from(usersTable).where(eq(usersTable.email, email)).limit(1);
  if (!user) {
    res.status(401).json({ message: "Invalid credentials" });
    return;
  }

  const valid = await comparePassword(password, user.passwordHash);
  if (!valid) {
    res.status(401).json({ message: "Invalid credentials" });
    return;
  }

  const token = signToken(user.id);
  res.json({
    user: { id: user.id, email: user.email, name: user.name, role: user.role, tier: user.tier, createdAt: user.createdAt.toISOString() },
    token,
  });
});

router.post("/logout", (_req, res): void => {
  res.json({ message: "Logged out" });
});

router.get("/me", requireAuth, (req, res): void => {
  const user = getUser(req);
  res.json({ id: user.id, email: user.email, name: user.name, role: user.role, tier: user.tier, createdAt: user.createdAt.toISOString() });
});

export default router;
