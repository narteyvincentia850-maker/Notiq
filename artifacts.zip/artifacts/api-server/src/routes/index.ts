import { Router, type IRouter } from "express";
import healthRouter from "./health.js";
import authRouter from "./auth.js";
import notesRouter from "./notes.js";
import assignmentsRouter from "./assignments.js";
import gradesRouter from "./grades.js";
import attendanceRouter from "./attendance.js";
import slidesRouter from "./slides.js";
import feedbackRouter from "./feedback.js";
import contactsRouter from "./contacts.js";
import projectsRouter from "./projects.js";
import invoicesRouter from "./invoices.js";
import aiRouter from "./ai.js";
import paymentsRouter from "./payments.js";
import exportRouter from "./export.js";
import dashboardRouter from "./dashboard.js";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/auth", authRouter);
router.use("/notes", notesRouter);
router.use("/assignments", assignmentsRouter);
router.use("/grades", gradesRouter);
router.use("/attendance", attendanceRouter);
router.use("/slides", slidesRouter);
router.use("/feedback", feedbackRouter);
router.use("/contacts", contactsRouter);
router.use("/projects", projectsRouter);
router.use("/invoices", invoicesRouter);
router.use("/ai", aiRouter);
router.use("/payments", paymentsRouter);
router.use("/export", exportRouter);
router.use("/dashboard", dashboardRouter);

export default router;
