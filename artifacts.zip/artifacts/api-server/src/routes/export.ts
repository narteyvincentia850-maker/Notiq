import { Router } from "express";
import { requireAuth, getUser } from "../lib/auth.js";
import { db, notesTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";

const router = Router();
router.use(requireAuth);

router.get("/note/:id", async (req, res): Promise<void> => {
  const user = getUser(req);
  const id = Number(req.params.id);
  const format = (req.query.format as string) ?? "text";

  const [note] = await db.select().from(notesTable).where(and(eq(notesTable.id, id), eq(notesTable.userId, user.id))).limit(1);
  if (!note) {
    res.status(404).json({ message: "Note not found" });
    return;
  }

  const lines: string[] = [
    `# ${note.title}`,
    `Portal: ${note.portal}`,
    `Created: ${note.createdAt.toISOString()}`,
    "",
  ];

  if (note.content) {
    lines.push("## Content", note.content, "");
  }
  if (note.transcription) {
    lines.push("## Transcription", note.transcription, "");
  }
  if (note.summary) {
    lines.push("## AI Summary", note.summary, "");
  }
  if (note.tags && note.tags.length > 0) {
    lines.push(`Tags: ${note.tags.join(", ")}`);
  }

  const content = lines.join("\n");
  const filename = `${note.title.replace(/[^a-z0-9]/gi, "_").toLowerCase()}.${format === "pdf" ? "txt" : "txt"}`;

  res.json({ content, format, filename });
});

export default router;
