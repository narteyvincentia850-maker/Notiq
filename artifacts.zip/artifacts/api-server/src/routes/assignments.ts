import { Router } from "express";
import { db, assignmentsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { requireAuth, getUser } from "../lib/auth.js";
import { CreateAssignmentBody, UpdateAssignmentBody } from "@workspace/api-zod";

const router = Router();
router.use(requireAuth);

router.get("/", async (req, res): Promise<void> => {
  const user = getUser(req);
  const rows = await db.select().from(assignmentsTable).where(eq(assignmentsTable.userId, user.id)).orderBy(assignmentsTable.dueDate);
  res.json(rows.map(r => ({ ...r, createdAt: r.createdAt.toISOString() })));
});

router.post("/", async (req, res): Promise<void> => {
  const user = getUser(req);
  const parsed = CreateAssignmentBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ message: "Invalid input" }); return; }
  const [row] = await db.insert(assignmentsTable).values({ ...parsed.data, userId: user.id }).returning();
  res.status(201).json({ ...row, createdAt: row.createdAt.toISOString() });
});

router.put("/:id", async (req, res): Promise<void> => {
  const user = getUser(req);
  const id = Number(req.params.id);
  const parsed = UpdateAssignmentBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ message: "Invalid input" }); return; }
  const [row] = await db.update(assignmentsTable).set(parsed.data).where(and(eq(assignmentsTable.id, id), eq(assignmentsTable.userId, user.id))).returning();
  if (!row) { res.status(404).json({ message: "Not found" }); return; }
  res.json({ ...row, createdAt: row.createdAt.toISOString() });
});

router.delete("/:id", async (req, res): Promise<void> => {
  const user = getUser(req);
  const id = Number(req.params.id);
  await db.delete(assignmentsTable).where(and(eq(assignmentsTable.id, id), eq(assignmentsTable.userId, user.id)));
  res.json({ message: "Deleted" });
});

export default router;
