import { Switch, Route, Router as WouterRouter, Redirect, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/components/auth-provider";
import NotFound from "@/pages/not-found";

import Landing from "@/pages/landing";
import Login from "@/pages/login";
import Register from "@/pages/register";

import StudentDashboard from "@/pages/student/dashboard";
import StudentNotes from "@/pages/student/notes";
import StudentRecorder from "@/pages/student/recorder";
import StudentAssignments from "@/pages/student/assignments";
import StudentGrades from "@/pages/student/grades";
import StudentChat from "@/pages/student/chat";

import ProfessorDashboard from "@/pages/professor/dashboard";
import ProfessorNotes from "@/pages/professor/notes";
import ProfessorRecorder from "@/pages/professor/recorder";
import ProfessorAttendance from "@/pages/professor/attendance";
import ProfessorSlides from "@/pages/professor/slides";
import ProfessorFeedback from "@/pages/professor/feedback";
import ProfessorChat from "@/pages/professor/chat";

import BusinessDashboard from "@/pages/business/dashboard";
import BusinessNotes from "@/pages/business/notes";
import BusinessRecorder from "@/pages/business/recorder";
import BusinessContacts from "@/pages/business/contacts";
import BusinessProjects from "@/pages/business/projects";
import BusinessInvoices from "@/pages/business/invoices";
import BusinessChat from "@/pages/business/chat";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      staleTime: 30_000,
    },
  },
});

function RequireAuth({ children, role }: { children: React.ReactNode; role?: string }) {
  const { user, isLoading, token } = useAuth();
  const [, setLocation] = useLocation();

  if (!token) return <Redirect to="/login" />;
  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }
  if (role && user && user.role !== role) return <Redirect to={`/${user.role}`} />;
  return <>{children}</>;
}

function GuestOnly({ children }: { children: React.ReactNode }) {
  const { user, token, isLoading } = useAuth();
  if (token && isLoading) return null;
  if (user) return <Redirect to={`/${user.role}`} />;
  return <>{children}</>;
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Landing} />
      <Route path="/login">
        <GuestOnly><Login /></GuestOnly>
      </Route>
      <Route path="/register">
        <GuestOnly><Register /></GuestOnly>
      </Route>

      {/* Student routes */}
      <Route path="/student">
        <RequireAuth role="student"><StudentDashboard /></RequireAuth>
      </Route>
      <Route path="/student/notes">
        <RequireAuth role="student"><StudentNotes /></RequireAuth>
      </Route>
      <Route path="/student/recorder">
        <RequireAuth role="student"><StudentRecorder /></RequireAuth>
      </Route>
      <Route path="/student/assignments">
        <RequireAuth role="student"><StudentAssignments /></RequireAuth>
      </Route>
      <Route path="/student/grades">
        <RequireAuth role="student"><StudentGrades /></RequireAuth>
      </Route>
      <Route path="/student/chat">
        <RequireAuth role="student"><StudentChat /></RequireAuth>
      </Route>

      {/* Professor routes */}
      <Route path="/professor">
        <RequireAuth role="professor"><ProfessorDashboard /></RequireAuth>
      </Route>
      <Route path="/professor/notes">
        <RequireAuth role="professor"><ProfessorNotes /></RequireAuth>
      </Route>
      <Route path="/professor/recorder">
        <RequireAuth role="professor"><ProfessorRecorder /></RequireAuth>
      </Route>
      <Route path="/professor/attendance">
        <RequireAuth role="professor"><ProfessorAttendance /></RequireAuth>
      </Route>
      <Route path="/professor/slides">
        <RequireAuth role="professor"><ProfessorSlides /></RequireAuth>
      </Route>
      <Route path="/professor/feedback">
        <RequireAuth role="professor"><ProfessorFeedback /></RequireAuth>
      </Route>
      <Route path="/professor/chat">
        <RequireAuth role="professor"><ProfessorChat /></RequireAuth>
      </Route>

      {/* Business routes */}
      <Route path="/business">
        <RequireAuth role="business"><BusinessDashboard /></RequireAuth>
      </Route>
      <Route path="/business/notes">
        <RequireAuth role="business"><BusinessNotes /></RequireAuth>
      </Route>
      <Route path="/business/recorder">
        <RequireAuth role="business"><BusinessRecorder /></RequireAuth>
      </Route>
      <Route path="/business/contacts">
        <RequireAuth role="business"><BusinessContacts /></RequireAuth>
      </Route>
      <Route path="/business/projects">
        <RequireAuth role="business"><BusinessProjects /></RequireAuth>
      </Route>
      <Route path="/business/invoices">
        <RequireAuth role="business"><BusinessInvoices /></RequireAuth>
      </Route>
      <Route path="/business/chat">
        <RequireAuth role="business"><BusinessChat /></RequireAuth>
      </Route>

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <AuthProvider>
            <Router />
          </AuthProvider>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
