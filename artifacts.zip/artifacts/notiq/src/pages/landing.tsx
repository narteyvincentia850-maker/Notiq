import { Link } from "wouter";
import { BookOpen, Mic, Brain, Shield, Zap, Users } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <nav className="border-b border-border px-6 py-4 flex items-center justify-between max-w-7xl mx-auto">
        <div className="flex items-center gap-2">
          <div className="bg-primary text-primary-foreground p-1.5 rounded-lg">
            <BookOpen className="w-5 h-5" />
          </div>
          <span className="text-xl font-bold tracking-tight">Notiq</span>
        </div>
        <div className="flex items-center gap-3">
          <Link href="/login"><Button variant="ghost">Sign In</Button></Link>
          <Link href="/register"><Button className="bg-primary text-primary-foreground hover:bg-primary/90">Get Started</Button></Link>
        </div>
      </nav>

      <section className="max-w-7xl mx-auto px-6 py-24 text-center">
        <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-8 border border-primary/20">
          <Zap className="w-4 h-4" /> Powered by Deepgram + Groq Llama 3
        </div>
        <h1 className="text-5xl md:text-7xl font-bold leading-tight mb-6 tracking-tight">
          Your AI-Powered<br />
          <span className="text-primary">Note-Taking</span> Platform
        </h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-10">
          Record audio, get instant transcriptions, AI summaries, and intelligent Q&A — built for students, professors, and business owners.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link href="/register"><Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 px-8">Start for Free</Button></Link>
          <Link href="/login"><Button size="lg" variant="outline" className="px-8">Sign In</Button></Link>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-6 py-16 grid md:grid-cols-3 gap-8">
        {[
          { icon: Users, title: "Three Portals", desc: "Dedicated workspaces for Students, Professors, and Business Owners." },
          { icon: Mic, title: "AI Audio Engine", desc: "Record speech, get Deepgram transcription + Groq Llama 3 summaries instantly." },
          { icon: Brain, title: "Smart Q&A Chat", desc: "Ask your AI assistant questions about your notes and lectures." },
        ].map(({ icon: Icon, title, desc }) => (
          <div key={title} className="bg-card border border-border rounded-xl p-6">
            <div className="bg-primary/10 text-primary w-10 h-10 rounded-lg flex items-center justify-center mb-4">
              <Icon className="w-5 h-5" />
            </div>
            <h3 className="font-semibold text-lg mb-2">{title}</h3>
            <p className="text-muted-foreground text-sm">{desc}</p>
          </div>
        ))}
      </section>

      <section className="max-w-7xl mx-auto px-6 py-16">
        <h2 className="text-3xl font-bold text-center mb-12">Choose Your Portal</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {[
            { role: "Student", features: ["Note taking", "Assignment tracking", "Grade monitoring", "AI Summaries"], color: "text-blue-400" },
            { role: "Professor", features: ["Attendance logs", "Lecture slides", "Automated feedback", "AI Chat"], color: "text-amber-400" },
            { role: "Business", features: ["CRM contacts", "Project milestones", "Billing & invoicing", "AI Summaries"], color: "text-green-400" },
          ].map(({ role, features, color }) => (
            <div key={role} className="bg-card border border-border rounded-xl p-6">
              <h3 className={`text-xl font-bold mb-4 ${color}`}>{role}</h3>
              <ul className="space-y-2">
                {features.map(f => (
                  <li key={f} className="text-sm text-muted-foreground flex items-center gap-2">
                    <Shield className="w-3 h-3 text-primary flex-shrink-0" /> {f}
                  </li>
                ))}
              </ul>
              <Link href="/register">
                <Button className="w-full mt-6 bg-primary/10 text-primary hover:bg-primary/20 border border-primary/20" variant="ghost">
                  Get Started as {role}
                </Button>
              </Link>
            </div>
          ))}
        </div>
      </section>

      <footer className="border-t border-border py-8 text-center text-muted-foreground text-sm">
        <p>Notiq &copy; 2026 — AI-powered note-taking for everyone.</p>
      </footer>
    </div>
  );
}
