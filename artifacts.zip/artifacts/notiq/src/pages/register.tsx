import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useRegister } from "@workspace/api-client-react";
import { useAuth } from "@/components/auth-provider";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { BookOpen, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const roles = [
  { value: "student", label: "Student", desc: "Notes, assignments & grades" },
  { value: "professor", label: "Professor", desc: "Attendance, slides & feedback" },
  { value: "business", label: "Business Owner", desc: "CRM, projects & invoices" },
] as const;

export default function Register() {
  const [, setLocation] = useLocation();
  const { setToken } = useAuth();
  const { toast } = useToast();
  const register = useRegister();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<"student" | "professor" | "business">("student");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    register.mutate(
      { data: { name, email, password, role } },
      {
        onSuccess: (data) => {
          setToken(data.token);
          setLocation(`/${data.user.role}`);
        },
        onError: () => {
          toast({ title: "Registration failed", description: "Email may already be in use.", variant: "destructive" });
        },
      }
    );
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 mb-4">
            <div className="bg-primary text-primary-foreground p-2 rounded-lg">
              <BookOpen className="w-5 h-5" />
            </div>
            <span className="text-2xl font-bold">Notiq</span>
          </div>
          <h1 className="text-2xl font-bold">Create your account</h1>
          <p className="text-muted-foreground mt-1 text-sm">Choose your portal to get started</p>
        </div>
        <div className="bg-card border border-border rounded-xl p-8">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Full Name</label>
              <Input data-testid="input-name" value={name} onChange={e => setName(e.target.value)} placeholder="Your name" required />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Email</label>
              <Input data-testid="input-email" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" required />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Password</label>
              <Input data-testid="input-password" type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" required minLength={6} />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">I am a...</label>
              <div className="grid grid-cols-1 gap-2">
                {roles.map(r => (
                  <button
                    key={r.value}
                    type="button"
                    data-testid={`role-${r.value}`}
                    onClick={() => setRole(r.value)}
                    className={`p-3 rounded-lg border text-left transition-colors ${role === r.value ? "border-primary bg-primary/10 text-primary" : "border-border bg-muted/30 hover:border-primary/50"}`}
                  >
                    <div className="font-medium text-sm">{r.label}</div>
                    <div className="text-xs text-muted-foreground">{r.desc}</div>
                  </button>
                ))}
              </div>
            </div>
            <Button data-testid="button-submit" type="submit" className="w-full bg-primary text-primary-foreground" disabled={register.isPending}>
              {register.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
              {register.isPending ? "Creating account..." : "Create Account"}
            </Button>
          </form>
          <p className="text-center text-sm text-muted-foreground mt-6">
            Already have an account?{" "}
            <Link href="/login" className="text-primary hover:underline">Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
