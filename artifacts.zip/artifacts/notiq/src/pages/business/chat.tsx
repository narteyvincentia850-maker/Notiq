import { useState, useRef, useEffect } from "react";
import { useChatWithAI } from "@workspace/api-client-react";
import { useAuth } from "@/components/auth-provider";
import { AppLayout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Send, Loader2, Bot, User } from "lucide-react";

interface Message { role: "user" | "assistant"; content: string; }

export default function BusinessChat() {
  const { token } = useAuth();
  const chatMutation = useChatWithAI({ request: { headers: { Authorization: `Bearer ${token}` } } });
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  const handleSend = () => {
    if (!input.trim() || chatMutation.isPending) return;
    const userMsg: Message = { role: "user", content: input };
    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setInput("");
    chatMutation.mutate(
      { data: { messages: newMessages } },
      { onSuccess: (data) => setMessages(prev => [...prev, { role: "assistant", content: data.message }]) }
    );
  };

  return (
    <AppLayout>
      <div className="flex flex-col h-[calc(100vh-12rem)]">
        <div className="mb-4">
          <h1 className="text-3xl font-bold">AI Business Assistant</h1>
          <p className="text-muted-foreground mt-1">Get insights on your business, invoices, and projects</p>
        </div>
        <div className="flex-1 bg-card border border-border rounded-xl flex flex-col overflow-hidden">
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.length === 0 && (
              <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
                <Bot className="w-12 h-12 mb-3 opacity-30" />
                <p className="text-sm">Ask your AI assistant about your business...</p>
              </div>
            )}
            {messages.map((m, i) => (
              <div key={i} className={`flex gap-3 ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                {m.role === "assistant" && <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0"><Bot className="w-4 h-4 text-primary" /></div>}
                <div className={`max-w-[75%] rounded-xl px-4 py-3 text-sm ${m.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted text-foreground"}`}>{m.content}</div>
                {m.role === "user" && <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center flex-shrink-0"><User className="w-4 h-4" /></div>}
              </div>
            ))}
            {chatMutation.isPending && (
              <div className="flex gap-3">
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center"><Bot className="w-4 h-4 text-primary" /></div>
                <div className="bg-muted rounded-xl px-4 py-3"><Loader2 className="w-4 h-4 animate-spin" /></div>
              </div>
            )}
            <div ref={bottomRef} />
          </div>
          <div className="border-t border-border p-4 flex gap-2">
            <Textarea placeholder="Ask about your business..." value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSend(); } }} className="resize-none min-h-[40px] max-h-[120px]" rows={1} />
            <Button onClick={handleSend} disabled={chatMutation.isPending || !input.trim()}><Send className="w-4 h-4" /></Button>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
