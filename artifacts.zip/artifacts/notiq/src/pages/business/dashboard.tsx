import { useGetBusinessDashboard, getGetBusinessDashboardQueryKey } from "@workspace/api-client-react";
import { useAuth } from "@/components/auth-provider";
import { AppLayout } from "@/components/layout";
import { BookOpen, Briefcase, FolderKanban, Receipt } from "lucide-react";

function StatCard({ icon: Icon, label, value, color }: { icon: any; label: string; value: string | number; color: string }) {
  return (
    <div className="bg-card border border-border rounded-xl p-5">
      <div className={`w-9 h-9 rounded-lg flex items-center justify-center mb-3 ${color}`}>
        <Icon className="w-4 h-4" />
      </div>
      <p className="text-2xl font-bold">{value}</p>
      <p className="text-sm text-muted-foreground">{label}</p>
    </div>
  );
}

export default function BusinessDashboard() {
  const { token } = useAuth();
  const { data, isLoading } = useGetBusinessDashboard({ request: { headers: { Authorization: `Bearer ${token}` } }, query: { queryKey: getGetBusinessDashboardQueryKey() } });

  if (isLoading) return <AppLayout><div className="space-y-4">{[1,2].map(i => <div key={i} className="h-24 bg-muted rounded-xl animate-pulse" />)}</div></AppLayout>;

  const totalRevenue = data?.invoiceSummary?.totalRevenue ?? 0;

  return (
    <AppLayout>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold">Business Dashboard</h1>
          <p className="text-muted-foreground mt-1">Your business overview</p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <StatCard icon={BookOpen} label="Total Notes" value={data?.totalNotes ?? 0} color="bg-blue-500/10 text-blue-400" />
          <StatCard icon={Briefcase} label="Contacts" value={data?.totalContacts ?? 0} color="bg-green-500/10 text-green-400" />
          <StatCard icon={FolderKanban} label="Active Projects" value={data?.activeProjects ?? 0} color="bg-purple-500/10 text-purple-400" />
          <StatCard icon={Receipt} label="Total Revenue" value={`₦${totalRevenue.toLocaleString()}`} color="bg-amber-500/10 text-amber-400" />
        </div>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-card border border-border rounded-xl p-5">
            <h2 className="font-semibold mb-4">Invoice Summary</h2>
            <div className="space-y-3">
              {[
                { label: "Paid", value: data?.invoiceSummary?.paid ?? 0, color: "text-green-400" },
                { label: "Pending", value: data?.invoiceSummary?.pending ?? 0, color: "text-amber-400" },
                { label: "Overdue", value: data?.invoiceSummary?.overdue ?? 0, color: "text-red-400" },
              ].map(({ label, value, color }) => (
                <div key={label} className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">{label}</span>
                  <span className={`font-semibold ${color}`}>{value}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="bg-card border border-border rounded-xl p-5">
            <h2 className="font-semibold mb-4">Recent Projects</h2>
            {data?.recentProjects?.length === 0 ? (
              <p className="text-muted-foreground text-sm">No projects yet.</p>
            ) : (
              <ul className="space-y-3">
                {data?.recentProjects?.map(p => (
                  <li key={p.id} className="flex items-center gap-3 text-sm">
                    <FolderKanban className="w-4 h-4 text-purple-400 flex-shrink-0" />
                    <span className="truncate">{p.name}</span>
                    <span className={`ml-auto text-xs px-2 py-0.5 rounded-full ${p.status === "active" ? "bg-green-500/10 text-green-400" : "bg-muted text-muted-foreground"}`}>{p.status}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
