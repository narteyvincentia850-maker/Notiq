import { useState } from "react";
import { useListContacts, useCreateContact, useDeleteContact, getListContactsQueryKey } from "@workspace/api-client-react";
import { useAuth } from "@/components/auth-provider";
import { AppLayout } from "@/components/layout";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Briefcase, Plus, Trash2, X, Loader2, Mail, Phone } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function BusinessContacts() {
  const { token } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const headers = { Authorization: `Bearer ${token}` };
  const { data: contacts, isLoading } = useListContacts({ request: { headers }, query: { queryKey: getListContactsQueryKey() } });
  const createContact = useCreateContact({ request: { headers } });
  const deleteContact = useDeleteContact({ request: { headers } });
  const [showForm, setShowForm] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [company, setCompany] = useState("");
  const [notes, setNotes] = useState("");

  const handleCreate = () => {
    if (!name) return;
    createContact.mutate(
      { data: { name, email, phone, company, notes } },
      {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getListContactsQueryKey() });
          setName(""); setEmail(""); setPhone(""); setCompany(""); setNotes(""); setShowForm(false);
          toast({ title: "Contact added" });
        },
      }
    );
  };

  const handleDelete = (id: number) => {
    deleteContact.mutate({ id }, { onSuccess: () => qc.invalidateQueries({ queryKey: getListContactsQueryKey() }) });
  };

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div><h1 className="text-3xl font-bold">Contacts</h1><p className="text-muted-foreground mt-1">Your CRM contacts</p></div>
          <Button onClick={() => setShowForm(!showForm)}><Plus className="w-4 h-4 mr-2" /> Add Contact</Button>
        </div>
        {showForm && (
          <div className="bg-card border border-border rounded-xl p-6 space-y-4">
            <div className="flex items-center justify-between"><h2 className="font-semibold">New Contact</h2><Button variant="ghost" size="icon" onClick={() => setShowForm(false)}><X className="w-4 h-4" /></Button></div>
            <div className="grid grid-cols-2 gap-4">
              <Input placeholder="Full Name *" value={name} onChange={e => setName(e.target.value)} />
              <Input placeholder="Company" value={company} onChange={e => setCompany(e.target.value)} />
              <Input type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} />
              <Input type="tel" placeholder="Phone" value={phone} onChange={e => setPhone(e.target.value)} />
              <Input placeholder="Notes" value={notes} onChange={e => setNotes(e.target.value)} className="col-span-2" />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
              <Button onClick={handleCreate} disabled={createContact.isPending}>{createContact.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}Save</Button>
            </div>
          </div>
        )}
        {isLoading ? (
          <div className="grid sm:grid-cols-2 gap-4">{[1,2,3,4].map(i => <div key={i} className="h-24 bg-muted rounded-xl animate-pulse" />)}</div>
        ) : contacts?.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground"><Briefcase className="w-10 h-10 mx-auto mb-3 opacity-30" /><p>No contacts yet.</p></div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {contacts?.map(c => (
              <div key={c.id} className="bg-card border border-border rounded-xl p-5">
                <div className="flex items-start justify-between mb-3">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-semibold text-sm">
                    {c.name.slice(0, 2).toUpperCase()}
                  </div>
                  <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => handleDelete(c.id)}><Trash2 className="w-3.5 h-3.5 text-destructive" /></Button>
                </div>
                <h3 className="font-semibold">{c.name}</h3>
                {c.company && <p className="text-xs text-muted-foreground mb-2">{c.company}</p>}
                <div className="space-y-1 mt-2">
                  {c.email && <p className="text-xs text-muted-foreground flex items-center gap-1.5"><Mail className="w-3 h-3" />{c.email}</p>}
                  {c.phone && <p className="text-xs text-muted-foreground flex items-center gap-1.5"><Phone className="w-3 h-3" />{c.phone}</p>}
                </div>
                {c.notes && <p className="text-xs text-muted-foreground/70 mt-2 line-clamp-2">{c.notes}</p>}
              </div>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
}
