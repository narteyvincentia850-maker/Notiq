import { useState } from "react";
import { useListNotes, useCreateNote, useDeleteNote, getListNotesQueryKey } from "@workspace/api-client-react";
import { useAuth } from "@/components/auth-provider";
import { AppLayout } from "@/components/layout";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { BookOpen, Plus, Trash2, Download, X, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function BusinessNotes() {
  const { token } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const headers = { Authorization: `Bearer ${token}` };
  const { data: notes, isLoading } = useListNotes({ portal: "business" }, { request: { headers }, query: { queryKey: getListNotesQueryKey({ portal: "business" }) } });
  const createNote = useCreateNote({ request: { headers } });
  const deleteNote = useDeleteNote({ request: { headers } });
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");

  const handleCreate = () => {
    if (!title.trim()) return;
    createNote.mutate(
      { data: { title, content, portal: "business" } },
      {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getListNotesQueryKey({ portal: "business" }) });
          setTitle(""); setContent(""); setShowForm(false);
          toast({ title: "Note created" });
        },
      }
    );
  };

  const handleDelete = (id: number) => {
    deleteNote.mutate({ id }, { onSuccess: () => qc.invalidateQueries({ queryKey: getListNotesQueryKey({ portal: "business" }) }) });
  };

  const handleExport = async (id: number, noteTitle: string) => {
    const res = await fetch(`/api/export/note/${id}?format=text`, { headers });
    const data = await res.json();
    const blob = new Blob([data.content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = data.filename; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div><h1 className="text-3xl font-bold">Business Notes</h1><p className="text-muted-foreground mt-1">Meeting notes and business insights</p></div>
          <Button onClick={() => setShowForm(!showForm)}><Plus className="w-4 h-4 mr-2" /> New Note</Button>
        </div>
        {showForm && (
          <div className="bg-card border border-border rounded-xl p-6 space-y-4">
            <div className="flex items-center justify-between"><h2 className="font-semibold">New Note</h2><Button variant="ghost" size="icon" onClick={() => setShowForm(false)}><X className="w-4 h-4" /></Button></div>
            <Input placeholder="Title" value={title} onChange={e => setTitle(e.target.value)} />
            <Textarea placeholder="Content..." value={content} onChange={e => setContent(e.target.value)} className="min-h-[100px]" />
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
              <Button onClick={handleCreate} disabled={createNote.isPending}>{createNote.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}Save</Button>
            </div>
          </div>
        )}
        {isLoading ? (
          <div className="space-y-3">{[1,2,3].map(i => <div key={i} className="h-20 bg-muted rounded-xl animate-pulse" />)}</div>
        ) : notes?.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground"><BookOpen className="w-10 h-10 mx-auto mb-3 opacity-30" /><p>No notes yet. Record a meeting!</p></div>
        ) : (
          <div className="grid gap-4">
            {notes?.map(note => (
              <div key={note.id} className="bg-card border border-border rounded-xl p-5 flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold truncate">{note.title}</h3>
                  {note.summary && <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{note.summary}</p>}
                  {!note.summary && note.content && <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{note.content}</p>}
                  <p className="text-xs text-muted-foreground/60 mt-2">{new Date(note.createdAt).toLocaleDateString()}</p>
                </div>
                <div className="flex gap-1 flex-shrink-0">
                  <Button variant="ghost" size="icon" onClick={() => handleExport(note.id, note.title)}><Download className="w-4 h-4" /></Button>
                  <Button variant="ghost" size="icon" onClick={() => handleDelete(note.id)}><Trash2 className="w-4 h-4 text-destructive" /></Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
}
