import { useState } from "react";
import { useListProjects, useCreateProject, useUpdateProject, getListProjectsQueryKey } from "@workspace/api-client-react";
import { useAuth } from "@/components/auth-provider";
import { AppLayout } from "@/components/layout";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { FolderKanban, Plus, X, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const statusColors: Record<string, string> = {
  active: "bg-green-500/10 text-green-400 border-green-500/20",
  completed: "bg-blue-500/10 text-blue-400 border-blue-500/20",
  on_hold: "bg-amber-500/10 text-amber-400 border-amber-500/20",
  cancelled: "bg-red-500/10 text-red-400 border-red-500/20",
};

export default function BusinessProjects() {
  const { token } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const headers = { Authorization: `Bearer ${token}` };
  const { data: projects, isLoading } = useListProjects({ request: { headers }, query: { queryKey: getListProjectsQueryKey() } });
  const createProject = useCreateProject({ request: { headers } });
  const updateProject = useUpdateProject({ request: { headers } });
  const [showForm, setShowForm] = useState(false);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [deadline, setDeadline] = useState("");
  const [client, setClient] = useState("");

  const handleCreate = () => {
    if (!name) return;
    createProject.mutate(
      { data: { name, description, deadline, client, status: "active" } },
      {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getListProjectsQueryKey() });
          setName(""); setDescription(""); setDeadline(""); setClient(""); setShowForm(false);
          toast({ title: "Project created" });
        },
      }
    );
  };

  const handleStatusChange = (id: number, status: string) => {
    updateProject.mutate({ id, data: { status: status as any } }, { onSuccess: () => qc.invalidateQueries({ queryKey: getListProjectsQueryKey() }) });
  };

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div><h1 className="text-3xl font-bold">Projects</h1><p className="text-muted-foreground mt-1">Track your business projects</p></div>
          <Button onClick={() => setShowForm(!showForm)}><Plus className="w-4 h-4 mr-2" /> New Project</Button>
        </div>
        {showForm && (
          <div className="bg-card border border-border rounded-xl p-6 space-y-4">
            <div className="flex items-center justify-between"><h2 className="font-semibold">New Project</h2><Button variant="ghost" size="icon" onClick={() => setShowForm(false)}><X className="w-4 h-4" /></Button></div>
            <div className="grid grid-cols-2 gap-4">
              <Input placeholder="Project Name *" value={name} onChange={e => setName(e.target.value)} />
              <Input placeholder="Client" value={client} onChange={e => setClient(e.target.value)} />
              <Input type="date" value={deadline} onChange={e => setDeadline(e.target.value)} />
              <div />
              <Textarea placeholder="Description" value={description} onChange={e => setDescription(e.target.value)} className="col-span-2 min-h-[80px]" />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
              <Button onClick={handleCreate} disabled={createProject.isPending}>{createProject.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}Save</Button>
            </div>
          </div>
        )}
        {isLoading ? (
          <div className="grid sm:grid-cols-2 gap-4">{[1,2,3].map(i => <div key={i} className="h-40 bg-muted rounded-xl animate-pulse" />)}</div>
        ) : projects?.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground"><FolderKanban className="w-10 h-10 mx-auto mb-3 opacity-30" /><p>No projects yet.</p></div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {projects?.map(p => (
              <div key={p.id} className="bg-card border border-border rounded-xl p-5 flex flex-col gap-3">
                <h3 className="font-semibold truncate">{p.name}</h3>
                {p.client && <p className="text-xs text-muted-foreground">Client: {p.client}</p>}
                {p.description && <p className="text-sm text-muted-foreground line-clamp-2">{p.description}</p>}
                {p.deadline && <p className="text-xs text-muted-foreground">Due: {p.deadline}</p>}
                <div className="pt-2 border-t border-border">
                  <select value={p.status} onChange={e => handleStatusChange(p.id, e.target.value)}
                    className={`w-full text-xs px-2 py-1.5 rounded-md border bg-transparent font-medium ${statusColors[p.status] ?? ""}`}>
                    <option value="active">Active</option>
                    <option value="on_hold">On Hold</option>
                    <option value="completed">Completed</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
}
