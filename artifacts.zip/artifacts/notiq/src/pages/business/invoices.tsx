import { useState } from "react";
import { useListInvoices, useCreateInvoice, useUpdateInvoice, getListInvoicesQueryKey } from "@workspace/api-client-react";
import { useAuth } from "@/components/auth-provider";
import { AppLayout } from "@/components/layout";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Receipt, Plus, X, Loader2, Download } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const statusColors: Record<string, string> = {
  draft: "bg-muted text-muted-foreground border-border",
  sent: "bg-blue-500/10 text-blue-400 border-blue-500/20",
  paid: "bg-green-500/10 text-green-400 border-green-500/20",
  overdue: "bg-red-500/10 text-red-400 border-red-500/20",
};

export default function BusinessInvoices() {
  const { token } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const headers = { Authorization: `Bearer ${token}` };
  const { data: invoices, isLoading } = useListInvoices({ request: { headers }, query: { queryKey: getListInvoicesQueryKey() } });
  const createInvoice = useCreateInvoice({ request: { headers } });
  const updateInvoice = useUpdateInvoice({ request: { headers } });
  const [showForm, setShowForm] = useState(false);
  const [client, setClient] = useState("");
  const [amount, setAmount] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [description, setDescription] = useState("");

  const handleCreate = () => {
    if (!client || !amount || !dueDate) return;
    createInvoice.mutate(
      { data: { client, amount: Number(amount), dueDate, description, status: "draft" } },
      {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getListInvoicesQueryKey() });
          setClient(""); setAmount(""); setDueDate(""); setDescription(""); setShowForm(false);
          toast({ title: "Invoice created" });
        },
      }
    );
  };

  const handleStatusChange = (id: number, status: string) => {
    updateInvoice.mutate({ id, data: { status: status as any } }, { onSuccess: () => qc.invalidateQueries({ queryKey: getListInvoicesQueryKey() }) });
  };

  const handleExport = async (id: number) => {
    const res = await fetch(`/api/export/invoice/${id}?format=text`, { headers });
    const data = await res.json();
    const blob = new Blob([data.content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = data.filename; a.click();
    URL.revokeObjectURL(url);
  };

  const totalPaid = invoices?.filter(i => i.status === "paid").reduce((s, i) => s + i.amount, 0) ?? 0;

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Invoices</h1>
            <p className="text-muted-foreground mt-1">Total paid: <span className="text-green-400 font-semibold">₦{totalPaid.toLocaleString()}</span></p>
          </div>
          <Button onClick={() => setShowForm(!showForm)}><Plus className="w-4 h-4 mr-2" /> New Invoice</Button>
        </div>
        {showForm && (
          <div className="bg-card border border-border rounded-xl p-6 space-y-4">
            <div className="flex items-center justify-between"><h2 className="font-semibold">New Invoice</h2><Button variant="ghost" size="icon" onClick={() => setShowForm(false)}><X className="w-4 h-4" /></Button></div>
            <div className="grid grid-cols-2 gap-4">
              <Input placeholder="Client Name *" value={client} onChange={e => setClient(e.target.value)} />
              <Input type="number" placeholder="Amount (₦) *" value={amount} onChange={e => setAmount(e.target.value)} />
              <div className="space-y-1"><label className="text-xs text-muted-foreground">Due Date *</label><Input type="date" value={dueDate} onChange={e => setDueDate(e.target.value)} /></div>
              <div />
              <Textarea placeholder="Description / line items" value={description} onChange={e => setDescription(e.target.value)} className="col-span-2 min-h-[80px]" />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
              <Button onClick={handleCreate} disabled={createInvoice.isPending}>{createInvoice.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}Create Invoice</Button>
            </div>
          </div>
        )}
        {isLoading ? (
          <div className="space-y-3">{[1,2,3].map(i => <div key={i} className="h-20 bg-muted rounded-xl animate-pulse" />)}</div>
        ) : invoices?.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground"><Receipt className="w-10 h-10 mx-auto mb-3 opacity-30" /><p>No invoices yet.</p></div>
        ) : (
          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <table className="w-full text-sm">
              <thead className="border-b border-border bg-muted/30">
                <tr>
                  <th className="text-left p-4 font-medium">Client</th>
                  <th className="text-left p-4 font-medium">Amount</th>
                  <th className="text-left p-4 font-medium">Due</th>
                  <th className="text-left p-4 font-medium">Status</th>
                  <th className="text-left p-4 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {invoices?.map(inv => (
                  <tr key={inv.id} className="border-b border-border last:border-0 hover:bg-muted/20">
                    <td className="p-4 font-medium">{inv.client}</td>
                    <td className="p-4">₦{inv.amount.toLocaleString()}</td>
                    <td className="p-4 text-muted-foreground">{inv.dueDate}</td>
                    <td className="p-4">
                      <select value={inv.status} onChange={e => handleStatusChange(inv.id, e.target.value)}
                        className={`text-xs px-2 py-1 rounded-md border bg-transparent font-medium ${statusColors[inv.status] ?? ""}`}>
                        <option value="draft">Draft</option>
                        <option value="sent">Sent</option>
                        <option value="paid">Paid</option>
                        <option value="overdue">Overdue</option>
                      </select>
                    </td>
                    <td className="p-4">
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => handleExport(inv.id)}><Download className="w-3.5 h-3.5" /></Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
