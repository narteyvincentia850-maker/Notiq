import { AppLayout } from "@/components/layout";
import { AudioRecorder } from "@/components/audio-recorder";

export default function BusinessRecorder() {
  return (
    <AppLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Meeting Recorder</h1>
          <p className="text-muted-foreground mt-1">Record meetings, calls, and get AI-powered summaries</p>
        </div>
        <AudioRecorder />
      </div>
    </AppLayout>
  );
}
