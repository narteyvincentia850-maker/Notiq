import { useGetStudentDashboard, getGetStudentDashboardQueryKey } from "@workspace/api-client-react";
import { useAuth } from "@/components/auth-provider";
import { AppLayout } from "@/components/layout";
import { BookOpen, CheckSquare, GraduationCap, TrendingUp } from "lucide-react";

function StatCard({ icon: Icon, label, value, color }: { icon: any; label: string; value: string | number; color: string }) {
  return (
    <div className="bg-card border border-border rounded-xl p-5">
      <div className={`w-9 h-9 rounded-lg flex items-center justify-center mb-3 ${color}`}>
        <Icon className="w-4 h-4" />
      </div>
      <p className="text-2xl font-bold">{value}</p>
      <p className="text-sm text-muted-foreground">{label}</p>
    </div>
  );
}

export default function StudentDashboard() {
  const { token } = useAuth();
  const { data, isLoading } = useGetStudentDashboard({ request: { headers: { Authorization: `Bearer ${token}` } }, query: { queryKey: getGetStudentDashboardQueryKey() } });

  if (isLoading) return <AppLayout><div className="animate-pulse space-y-4"><div className="h-24 bg-muted rounded-xl" /><div className="h-24 bg-muted rounded-xl" /></div></AppLayout>;

  return (
    <AppLayout>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold">Student Dashboard</h1>
          <p className="text-muted-foreground mt-1">Your academic overview</p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <StatCard icon={BookOpen} label="Total Notes" value={data?.totalNotes ?? 0} color="bg-blue-500/10 text-blue-400" />
          <StatCard icon={CheckSquare} label="Pending Assignments" value={data?.pendingAssignments ?? 0} color="bg-amber-500/10 text-amber-400" />
          <StatCard icon={GraduationCap} label="Avg Grade" value={`${(data?.averageGrade ?? 0).toFixed(1)}%`} color="bg-green-500/10 text-green-400" />
          <StatCard icon={TrendingUp} label="Grade Entries" value={data?.gradeBreakdown?.length ?? 0} color="bg-purple-500/10 text-purple-400" />
        </div>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-card border border-border rounded-xl p-5">
            <h2 className="font-semibold mb-4">Recent Notes</h2>
            {data?.recentNotes?.length === 0 ? (
              <p className="text-muted-foreground text-sm">No notes yet. Start recording!</p>
            ) : (
              <ul className="space-y-3">
                {data?.recentNotes?.map(n => (
                  <li key={n.id} className="flex items-center gap-3 text-sm">
                    <BookOpen className="w-4 h-4 text-primary flex-shrink-0" />
                    <span className="truncate">{n.title}</span>
                    <span className="text-muted-foreground ml-auto text-xs">{new Date(n.createdAt).toLocaleDateString()}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
          <div className="bg-card border border-border rounded-xl p-5">
            <h2 className="font-semibold mb-4">Upcoming Assignments</h2>
            {data?.upcomingAssignments?.length === 0 ? (
              <p className="text-muted-foreground text-sm">No pending assignments. Great work!</p>
            ) : (
              <ul className="space-y-3">
                {data?.upcomingAssignments?.map(a => (
                  <li key={a.id} className="flex items-center gap-3 text-sm">
                    <CheckSquare className="w-4 h-4 text-amber-400 flex-shrink-0" />
                    <span className="truncate">{a.title}</span>
                    <span className="text-muted-foreground ml-auto text-xs">{a.dueDate}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
        {(data?.gradeBreakdown?.length ?? 0) > 0 && (
          <div className="bg-card border border-border rounded-xl p-5">
            <h2 className="font-semibold mb-4">Grade Breakdown</h2>
            <div className="space-y-3">
              {data?.gradeBreakdown?.map(g => (
                <div key={g.subject} className="flex items-center gap-4">
                  <span className="text-sm w-32 truncate">{g.subject}</span>
                  <div className="flex-1 bg-muted rounded-full h-2">
                    <div className="bg-primary h-2 rounded-full" style={{ width: `${Math.min(g.score, 100)}%` }} />
                  </div>
                  <span className="text-sm font-medium w-12 text-right">{g.grade}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
