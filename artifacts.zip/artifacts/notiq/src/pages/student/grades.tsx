import { useState } from "react";
import { useListGrades, useCreateGrade, getListGradesQueryKey } from "@workspace/api-client-react";
import { useAuth } from "@/components/auth-provider";
import { AppLayout } from "@/components/layout";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { GraduationCap, Plus, X, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function StudentGrades() {
  const { token } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const headers = { Authorization: `Bearer ${token}` };
  const { data: grades, isLoading } = useListGrades({ request: { headers }, query: { queryKey: getListGradesQueryKey() } });
  const createGrade = useCreateGrade({ request: { headers } });
  const [showForm, setShowForm] = useState(false);
  const [subject, setSubject] = useState("");
  const [score, setScore] = useState("");
  const [maxScore, setMaxScore] = useState("100");
  const [grade, setGrade] = useState("");
  const [semester, setSemester] = useState("");

  const handleCreate = () => {
    if (!subject || !score || !grade || !semester) return;
    createGrade.mutate(
      { data: { subject, score: Number(score), maxScore: Number(maxScore), grade, semester } },
      {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getListGradesQueryKey() });
          setSubject(""); setScore(""); setMaxScore("100"); setGrade(""); setSemester(""); setShowForm(false);
          toast({ title: "Grade added" });
        },
      }
    );
  };

  const avg = grades?.length ? (grades.reduce((s, g) => s + g.score, 0) / grades.length).toFixed(1) : "—";

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div><h1 className="text-3xl font-bold">Grades</h1><p className="text-muted-foreground mt-1">Average: <span className="text-primary font-semibold">{avg}%</span></p></div>
          <Button onClick={() => setShowForm(!showForm)}><Plus className="w-4 h-4 mr-2" /> Add Grade</Button>
        </div>
        {showForm && (
          <div className="bg-card border border-border rounded-xl p-6 space-y-4">
            <div className="flex items-center justify-between"><h2 className="font-semibold">Add Grade</h2><Button variant="ghost" size="icon" onClick={() => setShowForm(false)}><X className="w-4 h-4" /></Button></div>
            <div className="grid grid-cols-2 gap-4">
              <Input placeholder="Subject" value={subject} onChange={e => setSubject(e.target.value)} />
              <Input placeholder="Semester (e.g. Fall 2025)" value={semester} onChange={e => setSemester(e.target.value)} />
              <Input type="number" placeholder="Score" value={score} onChange={e => setScore(e.target.value)} />
              <Input type="number" placeholder="Max Score" value={maxScore} onChange={e => setMaxScore(e.target.value)} />
              <Input placeholder="Grade (A, B+, etc.)" value={grade} onChange={e => setGrade(e.target.value)} />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
              <Button onClick={handleCreate} disabled={createGrade.isPending}>{createGrade.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}Save</Button>
            </div>
          </div>
        )}
        {isLoading ? (
          <div className="space-y-3">{[1,2,3].map(i => <div key={i} className="h-16 bg-muted rounded-xl animate-pulse" />)}</div>
        ) : grades?.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground"><GraduationCap className="w-10 h-10 mx-auto mb-3 opacity-30" /><p>No grades recorded yet.</p></div>
        ) : (
          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <table className="w-full text-sm">
              <thead className="border-b border-border bg-muted/30">
                <tr>
                  <th className="text-left p-4 font-medium">Subject</th>
                  <th className="text-left p-4 font-medium">Semester</th>
                  <th className="text-left p-4 font-medium">Score</th>
                  <th className="text-left p-4 font-medium">Grade</th>
                </tr>
              </thead>
              <tbody>
                {grades?.map(g => (
                  <tr key={g.id} data-testid={`row-grade-${g.id}`} className="border-b border-border last:border-0 hover:bg-muted/20">
                    <td className="p-4 font-medium">{g.subject}</td>
                    <td className="p-4 text-muted-foreground">{g.semester}</td>
                    <td className="p-4">{g.score}/{g.maxScore}</td>
                    <td className="p-4"><span className="font-semibold text-primary">{g.grade}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
