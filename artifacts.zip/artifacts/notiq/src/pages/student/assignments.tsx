import { useState } from "react";
import { useListAssignments, useCreateAssignment, useUpdateAssignment, useDeleteAssignment, getListAssignmentsQueryKey } from "@workspace/api-client-react";
import { useAuth } from "@/components/auth-provider";
import { AppLayout } from "@/components/layout";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { CheckSquare, Plus, Trash2, X, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const statusColors: Record<string, string> = {
  pending: "bg-amber-500/10 text-amber-400 border-amber-500/20",
  in_progress: "bg-blue-500/10 text-blue-400 border-blue-500/20",
  submitted: "bg-purple-500/10 text-purple-400 border-purple-500/20",
  graded: "bg-green-500/10 text-green-400 border-green-500/20",
};

export default function StudentAssignments() {
  const { token } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const headers = { Authorization: `Bearer ${token}` };
  const { data: assignments, isLoading } = useListAssignments({ request: { headers }, query: { queryKey: getListAssignmentsQueryKey() } });
  const createAssignment = useCreateAssignment({ request: { headers } });
  const updateAssignment = useUpdateAssignment({ request: { headers } });
  const deleteAssignment = useDeleteAssignment({ request: { headers } });
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [description, setDescription] = useState("");

  const handleCreate = () => {
    if (!title.trim() || !dueDate) return;
    createAssignment.mutate(
      { data: { title, dueDate, description, status: "pending" } },
      {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getListAssignmentsQueryKey() });
          setTitle(""); setDueDate(""); setDescription(""); setShowForm(false);
          toast({ title: "Assignment created" });
        },
      }
    );
  };

  const handleStatusChange = (id: number, status: string) => {
    updateAssignment.mutate(
      { id, data: { status: status as any } },
      { onSuccess: () => qc.invalidateQueries({ queryKey: getListAssignmentsQueryKey() }) }
    );
  };

  const handleDelete = (id: number) => {
    deleteAssignment.mutate({ id }, { onSuccess: () => qc.invalidateQueries({ queryKey: getListAssignmentsQueryKey() }) });
  };

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div><h1 className="text-3xl font-bold">Assignments</h1><p className="text-muted-foreground mt-1">Track your coursework</p></div>
          <Button onClick={() => setShowForm(!showForm)}><Plus className="w-4 h-4 mr-2" /> Add Assignment</Button>
        </div>
        {showForm && (
          <div className="bg-card border border-border rounded-xl p-6 space-y-4">
            <div className="flex items-center justify-between"><h2 className="font-semibold">New Assignment</h2><Button variant="ghost" size="icon" onClick={() => setShowForm(false)}><X className="w-4 h-4" /></Button></div>
            <Input placeholder="Assignment title" value={title} onChange={e => setTitle(e.target.value)} />
            <Input placeholder="Description" value={description} onChange={e => setDescription(e.target.value)} />
            <div className="space-y-1"><label className="text-sm font-medium">Due Date</label><Input type="date" value={dueDate} onChange={e => setDueDate(e.target.value)} /></div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
              <Button onClick={handleCreate} disabled={createAssignment.isPending}>{createAssignment.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}Save</Button>
            </div>
          </div>
        )}
        {isLoading ? (
          <div className="space-y-3">{[1,2,3].map(i => <div key={i} className="h-20 bg-muted rounded-xl animate-pulse" />)}</div>
        ) : assignments?.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground"><CheckSquare className="w-10 h-10 mx-auto mb-3 opacity-30" /><p>No assignments yet.</p></div>
        ) : (
          <div className="space-y-3">
            {assignments?.map(a => (
              <div key={a.id} data-testid={`card-assignment-${a.id}`} className="bg-card border border-border rounded-xl p-5 flex items-center gap-4">
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold">{a.title}</h3>
                  {a.description && <p className="text-sm text-muted-foreground">{a.description}</p>}
                  <p className="text-xs text-muted-foreground/60 mt-1">Due: {a.dueDate}</p>
                </div>
                <select
                  value={a.status}
                  onChange={e => handleStatusChange(a.id, e.target.value)}
                  className={`text-xs px-2 py-1 rounded-md border bg-transparent font-medium ${statusColors[a.status] ?? ""}`}
                >
                  <option value="pending">Pending</option>
                  <option value="in_progress">In Progress</option>
                  <option value="submitted">Submitted</option>
                  <option value="graded">Graded</option>
                </select>
                <Button variant="ghost" size="icon" onClick={() => handleDelete(a.id)}><Trash2 className="w-4 h-4 text-destructive" /></Button>
              </div>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
}
