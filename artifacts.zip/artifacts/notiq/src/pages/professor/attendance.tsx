import { useState } from "react";
import { useListAttendance, useCreateAttendance, getListAttendanceQueryKey } from "@workspace/api-client-react";
import { useAuth } from "@/components/auth-provider";
import { AppLayout } from "@/components/layout";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Users, Plus, X, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const statusColors: Record<string, string> = {
  present: "bg-green-500/10 text-green-400 border-green-500/20",
  absent: "bg-red-500/10 text-red-400 border-red-500/20",
  late: "bg-amber-500/10 text-amber-400 border-amber-500/20",
};

export default function ProfessorAttendance() {
  const { token } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const headers = { Authorization: `Bearer ${token}` };
  const { data: records, isLoading } = useListAttendance({ request: { headers }, query: { queryKey: getListAttendanceQueryKey() } });
  const createAttendance = useCreateAttendance({ request: { headers } });
  const [showForm, setShowForm] = useState(false);
  const [studentName, setStudentName] = useState("");
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [status, setStatus] = useState<"present" | "absent" | "late">("present");
  const [course, setCourse] = useState("");

  const handleCreate = () => {
    if (!studentName || !date || !course) return;
    createAttendance.mutate(
      { data: { studentName, date, status, course } },
      {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getListAttendanceQueryKey() });
          setStudentName(""); setShowForm(false);
          toast({ title: "Attendance recorded" });
        },
      }
    );
  };

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div><h1 className="text-3xl font-bold">Attendance</h1><p className="text-muted-foreground mt-1">Track student attendance</p></div>
          <Button onClick={() => setShowForm(!showForm)}><Plus className="w-4 h-4 mr-2" /> Record Attendance</Button>
        </div>
        {showForm && (
          <div className="bg-card border border-border rounded-xl p-6 space-y-4">
            <div className="flex items-center justify-between"><h2 className="font-semibold">New Attendance Record</h2><Button variant="ghost" size="icon" onClick={() => setShowForm(false)}><X className="w-4 h-4" /></Button></div>
            <div className="grid grid-cols-2 gap-4">
              <Input placeholder="Student Name" value={studentName} onChange={e => setStudentName(e.target.value)} />
              <Input placeholder="Course" value={course} onChange={e => setCourse(e.target.value)} />
              <Input type="date" value={date} onChange={e => setDate(e.target.value)} />
              <div className="flex gap-2">
                {(["present", "absent", "late"] as const).map(s => (
                  <button key={s} type="button" onClick={() => setStatus(s)}
                    className={`flex-1 py-2 rounded-md border text-xs font-medium capitalize transition-colors ${status === s ? statusColors[s] : "border-border text-muted-foreground hover:border-primary/50"}`}>
                    {s}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
              <Button onClick={handleCreate} disabled={createAttendance.isPending}>{createAttendance.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}Record</Button>
            </div>
          </div>
        )}
        {isLoading ? (
          <div className="space-y-3">{[1,2,3].map(i => <div key={i} className="h-16 bg-muted rounded-xl animate-pulse" />)}</div>
        ) : records?.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground"><Users className="w-10 h-10 mx-auto mb-3 opacity-30" /><p>No attendance records yet.</p></div>
        ) : (
          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <table className="w-full text-sm">
              <thead className="border-b border-border bg-muted/30">
                <tr>
                  <th className="text-left p-4 font-medium">Student</th>
                  <th className="text-left p-4 font-medium">Course</th>
                  <th className="text-left p-4 font-medium">Date</th>
                  <th className="text-left p-4 font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                {records?.map(r => (
                  <tr key={r.id} className="border-b border-border last:border-0 hover:bg-muted/20">
                    <td className="p-4 font-medium">{r.studentName}</td>
                    <td className="p-4 text-muted-foreground">{r.course}</td>
                    <td className="p-4 text-muted-foreground">{r.date}</td>
                    <td className="p-4"><span className={`text-xs px-2 py-0.5 rounded-full border capitalize font-medium ${statusColors[r.status] ?? ""}`}>{r.status}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
