import { useGetProfessorDashboard, getGetProfessorDashboardQueryKey } from "@workspace/api-client-react";
import { useAuth } from "@/components/auth-provider";
import { AppLayout } from "@/components/layout";
import { BookOpen, Users, MessageCircle, FileText } from "lucide-react";

function StatCard({ icon: Icon, label, value, color }: { icon: any; label: string; value: string | number; color: string }) {
  return (
    <div className="bg-card border border-border rounded-xl p-5">
      <div className={`w-9 h-9 rounded-lg flex items-center justify-center mb-3 ${color}`}>
        <Icon className="w-4 h-4" />
      </div>
      <p className="text-2xl font-bold">{value}</p>
      <p className="text-sm text-muted-foreground">{label}</p>
    </div>
  );
}

export default function ProfessorDashboard() {
  const { token } = useAuth();
  const { data, isLoading } = useGetProfessorDashboard({ request: { headers: { Authorization: `Bearer ${token}` } }, query: { queryKey: getGetProfessorDashboardQueryKey() } });

  if (isLoading) return <AppLayout><div className="space-y-4"><div className="h-24 bg-muted rounded-xl animate-pulse" /></div></AppLayout>;

  return (
    <AppLayout>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold">Professor Dashboard</h1>
          <p className="text-muted-foreground mt-1">Your teaching overview</p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <StatCard icon={BookOpen} label="Total Notes" value={data?.totalNotes ?? 0} color="bg-blue-500/10 text-blue-400" />
          <StatCard icon={Users} label="Attendance Records" value={data?.attendanceRecords ?? 0} color="bg-green-500/10 text-green-400" />
          <StatCard icon={FileText} label="Slides Uploaded" value={data?.slidesUploaded ?? 0} color="bg-purple-500/10 text-purple-400" />
          <StatCard icon={MessageCircle} label="Feedback Items" value={data?.feedbackCount ?? 0} color="bg-amber-500/10 text-amber-400" />
        </div>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-card border border-border rounded-xl p-5">
            <h2 className="font-semibold mb-4">Recent Attendance</h2>
            {data?.recentAttendance?.length === 0 ? (
              <p className="text-muted-foreground text-sm">No attendance records yet.</p>
            ) : (
              <ul className="space-y-3">
                {data?.recentAttendance?.map(r => (
                  <li key={r.id} className="flex items-center gap-3 text-sm">
                    <Users className="w-4 h-4 text-green-400 flex-shrink-0" />
                    <span className="truncate">{r.studentName}</span>
                    <span className={`ml-auto text-xs px-2 py-0.5 rounded-full ${r.status === "present" ? "bg-green-500/10 text-green-400" : "bg-red-500/10 text-red-400"}`}>{r.status}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
          <div className="bg-card border border-border rounded-xl p-5">
            <h2 className="font-semibold mb-4">Recent Feedback</h2>
            {data?.recentFeedback?.length === 0 ? (
              <p className="text-muted-foreground text-sm">No feedback yet.</p>
            ) : (
              <ul className="space-y-3">
                {data?.recentFeedback?.map(f => (
                  <li key={f.id} className="text-sm">
                    <p className="truncate text-foreground">{f.content}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{new Date(f.createdAt).toLocaleDateString()}</p>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
