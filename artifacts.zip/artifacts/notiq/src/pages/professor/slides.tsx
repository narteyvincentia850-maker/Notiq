import { useState } from "react";
import { useListSlides, useCreateSlide, getListSlidesQueryKey } from "@workspace/api-client-react";
import { useAuth } from "@/components/auth-provider";
import { AppLayout } from "@/components/layout";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { FileText, Plus, X, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function ProfessorSlides() {
  const { token } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const headers = { Authorization: `Bearer ${token}` };
  const { data: slides, isLoading } = useListSlides({ request: { headers }, query: { queryKey: getListSlidesQueryKey() } });
  const createSlide = useCreateSlide({ request: { headers } });
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [course, setCourse] = useState("");

  const handleCreate = () => {
    if (!title || !course) return;
    createSlide.mutate(
      { data: { title, content, course } },
      {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getListSlidesQueryKey() });
          setTitle(""); setContent(""); setCourse(""); setShowForm(false);
          toast({ title: "Slide created" });
        },
      }
    );
  };

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div><h1 className="text-3xl font-bold">Lecture Slides</h1><p className="text-muted-foreground mt-1">Manage your course materials</p></div>
          <Button onClick={() => setShowForm(!showForm)}><Plus className="w-4 h-4 mr-2" /> Add Slide</Button>
        </div>
        {showForm && (
          <div className="bg-card border border-border rounded-xl p-6 space-y-4">
            <div className="flex items-center justify-between"><h2 className="font-semibold">New Slide</h2><Button variant="ghost" size="icon" onClick={() => setShowForm(false)}><X className="w-4 h-4" /></Button></div>
            <div className="grid grid-cols-2 gap-4">
              <Input placeholder="Title" value={title} onChange={e => setTitle(e.target.value)} />
              <Input placeholder="Course" value={course} onChange={e => setCourse(e.target.value)} />
            </div>
            <Textarea placeholder="Slide content..." value={content} onChange={e => setContent(e.target.value)} className="min-h-[100px]" />
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
              <Button onClick={handleCreate} disabled={createSlide.isPending}>{createSlide.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}Save</Button>
            </div>
          </div>
        )}
        {isLoading ? (
          <div className="grid grid-cols-2 gap-4">{[1,2,3,4].map(i => <div key={i} className="h-32 bg-muted rounded-xl animate-pulse" />)}</div>
        ) : slides?.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground"><FileText className="w-10 h-10 mx-auto mb-3 opacity-30" /><p>No slides yet.</p></div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {slides?.map(slide => (
              <div key={slide.id} className="bg-card border border-border rounded-xl p-5 flex flex-col">
                <div className="flex items-start justify-between mb-2">
                  <FileText className="w-5 h-5 text-primary mt-0.5" />
                </div>
                <h3 className="font-semibold truncate">{slide.title}</h3>
                <p className="text-xs text-primary/80 mb-2">{slide.course}</p>
                {slide.content && <p className="text-sm text-muted-foreground line-clamp-3 flex-1">{slide.content}</p>}
                <p className="text-xs text-muted-foreground/60 mt-3">{new Date(slide.createdAt).toLocaleDateString()}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
}
