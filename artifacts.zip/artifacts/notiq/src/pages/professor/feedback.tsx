import { useState } from "react";
import { useListFeedback, useCreateFeedback, getListFeedbackQueryKey } from "@workspace/api-client-react";
import { useAuth } from "@/components/auth-provider";
import { AppLayout } from "@/components/layout";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { MessageCircle, Plus, X, Loader2, Star } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function ProfessorFeedback() {
  const { token } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const headers = { Authorization: `Bearer ${token}` };
  const { data: feedback, isLoading } = useListFeedback({ request: { headers }, query: { queryKey: getListFeedbackQueryKey() } });
  const createFeedback = useCreateFeedback({ request: { headers } });
  const [showForm, setShowForm] = useState(false);
  const [studentName, setStudentName] = useState("");
  const [content, setContent] = useState("");
  const [rating, setRating] = useState(5);
  const [course, setCourse] = useState("");

  const handleCreate = () => {
    if (!studentName || !content || !course) return;
    createFeedback.mutate(
      { data: { studentName, content, rating, course } },
      {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getListFeedbackQueryKey() });
          setStudentName(""); setContent(""); setRating(5); setCourse(""); setShowForm(false);
          toast({ title: "Feedback added" });
        },
      }
    );
  };

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div><h1 className="text-3xl font-bold">Student Feedback</h1><p className="text-muted-foreground mt-1">Record and review student feedback</p></div>
          <Button onClick={() => setShowForm(!showForm)}><Plus className="w-4 h-4 mr-2" /> Add Feedback</Button>
        </div>
        {showForm && (
          <div className="bg-card border border-border rounded-xl p-6 space-y-4">
            <div className="flex items-center justify-between"><h2 className="font-semibold">New Feedback</h2><Button variant="ghost" size="icon" onClick={() => setShowForm(false)}><X className="w-4 h-4" /></Button></div>
            <div className="grid grid-cols-2 gap-4">
              <Input placeholder="Student Name" value={studentName} onChange={e => setStudentName(e.target.value)} />
              <Input placeholder="Course" value={course} onChange={e => setCourse(e.target.value)} />
            </div>
            <Textarea placeholder="Feedback content..." value={content} onChange={e => setContent(e.target.value)} className="min-h-[80px]" />
            <div className="flex items-center gap-2">
              <label className="text-sm font-medium">Rating:</label>
              {[1,2,3,4,5].map(r => (
                <button key={r} type="button" onClick={() => setRating(r)}>
                  <Star className={`w-5 h-5 ${r <= rating ? "fill-amber-400 text-amber-400" : "text-muted-foreground"}`} />
                </button>
              ))}
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
              <Button onClick={handleCreate} disabled={createFeedback.isPending}>{createFeedback.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}Save</Button>
            </div>
          </div>
        )}
        {isLoading ? (
          <div className="space-y-3">{[1,2,3].map(i => <div key={i} className="h-24 bg-muted rounded-xl animate-pulse" />)}</div>
        ) : feedback?.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground"><MessageCircle className="w-10 h-10 mx-auto mb-3 opacity-30" /><p>No feedback yet.</p></div>
        ) : (
          <div className="grid gap-4">
            {feedback?.map(f => (
              <div key={f.id} className="bg-card border border-border rounded-xl p-5">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h3 className="font-semibold">{f.studentName}</h3>
                    <p className="text-xs text-muted-foreground">{f.course}</p>
                  </div>
                  <div className="flex gap-0.5">
                    {[1,2,3,4,5].map(r => <Star key={r} className={`w-4 h-4 ${r <= f.rating ? "fill-amber-400 text-amber-400" : "text-muted-foreground/30"}`} />)}
                  </div>
                </div>
                <p className="text-sm text-muted-foreground">{f.content}</p>
                <p className="text-xs text-muted-foreground/60 mt-2">{new Date(f.createdAt).toLocaleDateString()}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
}
