import { AppLayout } from "@/components/layout";
import { AudioRecorder } from "@/components/audio-recorder";

export default function ProfessorRecorder() {
  return (
    <AppLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Lecture Recorder</h1>
          <p className="text-muted-foreground mt-1">Record your lectures and get AI-powered transcriptions and summaries</p>
        </div>
        <AudioRecorder />
      </div>
    </AppLayout>
  );
}
