import { Sidebar } from "./sidebar";
import { AdBanner } from "./ad-banner";

export function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar />
      <main className="flex-1 overflow-y-auto flex flex-col pt-16 md:pt-0">
        <div className="flex-1 p-6 md:p-10 max-w-7xl mx-auto w-full">
          {children}
        </div>
        <div className="px-6 md:px-10 pb-6 max-w-7xl mx-auto w-full">
          <AdBanner />
        </div>
      </main>
    </div>
  );
}
