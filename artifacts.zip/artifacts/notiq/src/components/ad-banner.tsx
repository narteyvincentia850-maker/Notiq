import { useAuth } from "./auth-provider";
import { Link } from "wouter";

export function AdBanner() {
  const { user } = useAuth();

  if (user?.tier !== "free") return null;

  return (
    <div className="w-full mt-8 p-4 bg-muted/30 border border-border rounded-lg text-center flex flex-col items-center justify-center">
      <p className="text-sm text-muted-foreground mb-2">Advertisement</p>
      <div className="w-full max-w-2xl bg-card border border-border rounded p-6">
        <h3 className="font-bold text-lg mb-2">Upgrade to Notiq Premium</h3>
        <p className="text-sm text-muted-foreground mb-4">Get unlimited AI transcriptions, smart summaries, and remove all ads.</p>
        <Link href="#" className="text-primary font-medium hover:underline">
          Learn more &rarr;
        </Link>
      </div>
    </div>
  );
}
