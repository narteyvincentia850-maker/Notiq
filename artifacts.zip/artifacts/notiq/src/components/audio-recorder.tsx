import { useState, useRef } from "react";
import { useTranscribeAudio, useSummarizeText, useCreateNote } from "@workspace/api-client-react";
import { Button } from "./ui/button";
import { Mic, Square, Loader2, Save, FileText, CheckCircle2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Textarea } from "./ui/textarea";
import { Input } from "./ui/input";
import { useAuth } from "./auth-provider";
import { NotePortal } from "@workspace/api-client-react/src/generated/api.schemas";
import { useLocation } from "wouter";

export function AudioRecorder() {
  const { user, token } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [isRecording, setIsRecording] = useState(false);
  const [audioBase64, setAudioBase64] = useState<string | null>(null);
  const [mimeType, setMimeType] = useState<string>("");
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  
  const [transcript, setTranscript] = useState("");
  const [summary, setSummary] = useState("");
  const [title, setTitle] = useState("Meeting Notes");

  const transcribe = useTranscribeAudio({ request: { headers: { Authorization: `Bearer ${token}` } } });
  const summarize = useSummarizeText({ request: { headers: { Authorization: `Bearer ${token}` } } });
  const createNote = useCreateNote({ request: { headers: { Authorization: `Bearer ${token}` } } });

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: mediaRecorder.mimeType });
        setMimeType(mediaRecorder.mimeType);
        const reader = new FileReader();
        reader.readAsDataURL(blob);
        reader.onloadend = () => {
          const base64String = reader.result as string;
          // Extract base64 without prefix
          const base64 = base64String.split(",")[1];
          setAudioBase64(base64);
        };
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (err) {
      toast({ title: "Microphone Error", description: "Could not access microphone.", variant: "destructive" });
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
    }
  };

  const handleTranscribe = () => {
    if (!audioBase64) return;
    transcribe.mutate(
      { data: { audioBase64, mimeType } },
      {
        onSuccess: (data) => {
          setTranscript(data.transcript);
          toast({ title: "Transcription complete" });
        },
        onError: () => {
          toast({ title: "Transcription failed", variant: "destructive" });
        }
      }
    );
  };

  const handleSummarize = () => {
    if (!transcript) return;
    summarize.mutate(
      { data: { text: transcript } },
      {
        onSuccess: (data) => {
          setSummary(data.summary);
          toast({ title: "Summary generated" });
        }
      }
    );
  };

  const handleSaveNote = () => {
    if (!transcript && !summary) return;
    createNote.mutate(
      {
        data: {
          title,
          content: summary || transcript,
          transcription: transcript,
          summary,
          portal: user?.role as NotePortal || "student"
        }
      },
      {
        onSuccess: () => {
          toast({ title: "Note saved successfully" });
          setLocation(`/${user?.role}/notes`);
        }
      }
    );
  };

  return (
    <div className="bg-card border border-border rounded-xl p-6 shadow-sm space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Audio Recorder</h2>
          <p className="text-muted-foreground text-sm mt-1">Record, transcribe, and summarize in one click.</p>
        </div>
        <div className="flex items-center gap-4">
          {isRecording ? (
            <Button variant="destructive" onClick={stopRecording} className="animate-pulse">
              <Square className="w-4 h-4 mr-2" /> Stop Recording
            </Button>
          ) : (
            <Button onClick={startRecording} className="bg-primary text-primary-foreground">
              <Mic className="w-4 h-4 mr-2" /> Start Recording
            </Button>
          )}
        </div>
      </div>

      {audioBase64 && !isRecording && (
        <div className="bg-muted/50 p-4 rounded-lg flex items-center justify-between">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="text-green-500 w-5 h-5" />
            <span className="font-medium">Audio recorded successfully</span>
          </div>
          <Button 
            onClick={handleTranscribe} 
            disabled={transcribe.isPending}
            variant="secondary"
          >
            {transcribe.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <FileText className="w-4 h-4 mr-2" />}
            {transcribe.isPending ? "Transcribing..." : "Transcribe"}
          </Button>
        </div>
      )}

      {transcript && (
        <div className="space-y-4">
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <label className="text-sm font-semibold">Transcript</label>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handleSummarize}
                disabled={summarize.isPending}
              >
                {summarize.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
                Summarize
              </Button>
            </div>
            <Textarea 
              value={transcript} 
              onChange={(e) => setTranscript(e.target.value)}
              className="min-h-[150px] font-mono text-sm"
            />
          </div>

          {summary && (
            <div className="space-y-2">
              <label className="text-sm font-semibold text-accent">AI Summary</label>
              <Textarea 
                value={summary}
                onChange={(e) => setSummary(e.target.value)}
                className="min-h-[100px] border-accent/50 focus-visible:ring-accent"
              />
            </div>
          )}

          <div className="pt-4 border-t border-border space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Note Title</label>
                <Input value={title} onChange={(e) => setTitle(e.target.value)} />
              </div>
            </div>
            <div className="flex justify-end">
              <Button onClick={handleSaveNote} disabled={createNote.isPending}>
                <Save className="w-4 h-4 mr-2" /> Save to Notes
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
