import { Link, useLocation } from "wouter";
import { useAuth } from "./auth-provider";
import { useInitializePayment } from "@workspace/api-client-react";
import { 
  BookOpen, 
  CheckSquare, 
  GraduationCap, 
  MessageSquare, 
  Mic, 
  LayoutDashboard, 
  Users, 
  FileText, 
  MessageCircle, 
  Briefcase, 
  FolderKanban, 
  Receipt,
  LogOut,
  Crown,
  Menu,
  X
} from "lucide-react";
import { useState } from "react";
import { Button } from "./ui/button";

interface NavItem {
  label: string;
  href: string;
  icon: React.ElementType;
}

const studentNav: NavItem[] = [
  { label: "Dashboard", href: "/student", icon: LayoutDashboard },
  { label: "Notes", href: "/student/notes", icon: BookOpen },
  { label: "Recorder", href: "/student/recorder", icon: Mic },
  { label: "Assignments", href: "/student/assignments", icon: CheckSquare },
  { label: "Grades", href: "/student/grades", icon: GraduationCap },
  { label: "Chat AI", href: "/student/chat", icon: MessageSquare },
];

const professorNav: NavItem[] = [
  { label: "Dashboard", href: "/professor", icon: LayoutDashboard },
  { label: "Lecture Notes", href: "/professor/notes", icon: BookOpen },
  { label: "Recorder", href: "/professor/recorder", icon: Mic },
  { label: "Attendance", href: "/professor/attendance", icon: Users },
  { label: "Slides", href: "/professor/slides", icon: FileText },
  { label: "Feedback", href: "/professor/feedback", icon: MessageCircle },
  { label: "Chat AI", href: "/professor/chat", icon: MessageSquare },
];

const businessNav: NavItem[] = [
  { label: "Dashboard", href: "/business", icon: LayoutDashboard },
  { label: "Notes", href: "/business/notes", icon: BookOpen },
  { label: "Recorder", href: "/business/recorder", icon: Mic },
  { label: "Contacts", href: "/business/contacts", icon: Briefcase },
  { label: "Projects", href: "/business/projects", icon: FolderKanban },
  { label: "Invoices", href: "/business/invoices", icon: Receipt },
  { label: "Chat AI", href: "/business/chat", icon: MessageSquare },
];

export function Sidebar() {
  const [location, setLocation] = useLocation();
  const { user, logout, token } = useAuth();
  const initPayment = useInitializePayment();
  const [isOpen, setIsOpen] = useState(false);

  let navItems: NavItem[] = [];
  if (user?.role === "student") navItems = studentNav;
  if (user?.role === "professor") navItems = professorNav;
  if (user?.role === "business") navItems = businessNav;

  const handleUpgrade = () => {
    initPayment.mutate(
      { data: { email: user?.email || "", amount: 1500, plan: "monthly" } },
      {
        onSuccess: (res) => {
          window.location.href = res.authorizationUrl;
        }
      }
    );
  };

  const SidebarContent = (
    <div className="flex flex-col h-full bg-sidebar border-r border-sidebar-border text-sidebar-foreground w-64">
      <div className="p-6 flex items-center gap-3">
        <div className="bg-primary text-primary-foreground p-2 rounded-lg">
          <BookOpen className="w-5 h-5" />
        </div>
        <span className="text-xl font-bold tracking-tight">Notiq</span>
      </div>
      
      <div className="flex-1 px-4 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const isActive = location === item.href;
          return (
            <Link 
              key={item.href} 
              href={item.href}
              onClick={() => setIsOpen(false)}
              className={`flex items-center gap-3 px-3 py-2 rounded-md transition-colors ${
                isActive 
                  ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium" 
                  : "hover:bg-sidebar-accent/50 text-sidebar-foreground/80 hover:text-sidebar-foreground"
              }`}
            >
              <item.icon className="w-4 h-4" />
              {item.label}
            </Link>
          );
        })}
      </div>

      <div className="p-4 border-t border-sidebar-border space-y-4">
        {user?.tier === "free" && (
          <div className="bg-sidebar-accent/10 p-4 rounded-lg border border-sidebar-accent/20">
            <h4 className="text-sm font-semibold mb-1 flex items-center gap-2">
              <Crown className="w-4 h-4 text-sidebar-accent" />
              Free Plan
            </h4>
            <p className="text-xs text-sidebar-foreground/70 mb-3">Upgrade for unlimited AI transcription and ad-free experience.</p>
            <Button 
              className="w-full bg-sidebar-accent text-sidebar-accent-foreground hover:bg-sidebar-accent/90" 
              size="sm"
              onClick={handleUpgrade}
              disabled={initPayment.isPending}
            >
              {initPayment.isPending ? "Processing..." : "Upgrade to Premium"}
            </Button>
          </div>
        )}
        <div className="flex items-center justify-between px-2">
          <div className="flex flex-col">
            <span className="text-sm font-medium">{user?.name}</span>
            <span className="text-xs text-sidebar-foreground/60 capitalize">{user?.role}</span>
          </div>
          <Button variant="ghost" size="icon" onClick={() => { logout(); setLocation("/login"); }}>
            <LogOut className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );

  return (
    <>
      <div className="md:hidden fixed top-0 left-0 w-full h-16 bg-sidebar border-b border-sidebar-border z-40 flex items-center px-4 justify-between">
        <div className="flex items-center gap-2 text-sidebar-foreground">
          <BookOpen className="w-5 h-5 text-primary" />
          <span className="font-bold text-lg">Notiq</span>
        </div>
        <Button variant="ghost" size="icon" className="text-sidebar-foreground" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </Button>
      </div>

      {isOpen && (
        <div className="md:hidden fixed inset-0 bg-background/80 backdrop-blur-sm z-40" onClick={() => setIsOpen(false)} />
      )}

      <div className={`fixed inset-y-0 left-0 z-50 transform transition-transform duration-200 ease-in-out md:translate-x-0 md:static md:h-screen ${isOpen ? "translate-x-0" : "-translate-x-full"}`}>
        {SidebarContent}
      </div>
    </>
  );
}
